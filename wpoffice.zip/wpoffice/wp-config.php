<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wpoffice');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '/{Mnv3umcr]f9q]}w&Bnn;<a+LnFjURwSTe*{J2c][wc^=cr[n.qE-QjDj{=ycoA');
define('SECURE_AUTH_KEY',  '5$5[?zl2[F8XBozM2MYqCLQr}|LxDw2ZCBjNw_#yUdE08C.)bT6I`o^Nu7:T 0oS');
define('LOGGED_IN_KEY',    '3f53N/<vH5%vi`7Utf-j5}AEy0!Mjd39oMR%B{kS}92(e[&x<52}C9Te-n5<I,[c');
define('NONCE_KEY',        'Oc/6{kZ*!.o3Wx*p&}[#hx]Y?I!#oeC*-`e:.Ut?GM]~%wHS;va00rR,Q/1ox_5h');
define('AUTH_SALT',        'n<8tod@4OHHB*.$un`C.&S?q=G%?6(PG5<Z{UzLS*SKVYXWi4z$d707A1LGP`a:9');
define('SECURE_AUTH_SALT', 'Sw*QWjW+o;Ddw&rc|02zVwvOSskJ|PM)p.|7I1,kh(6?: s&(]zDD.&#Er<yr-3)');
define('LOGGED_IN_SALT',   '=TPaH E@1^p(6xlL;3sH|mCIMJ<%r$_#5%{[`h;tzN=*>MO<Jpo(%WVj)pC d#y0');
define('NONCE_SALT',       'fm,FxAF .~xw7/Wm~/T0nR~$l0]$qF`cJoa7jZQKE1qVV=h+gU`Wsx*t!iCw3M0@');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
